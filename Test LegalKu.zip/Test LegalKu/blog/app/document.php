<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class document extends Model
{
    protected $table = 'documents';
    protected $primaryKey = 'documentId';

    protected $fillable = [
        'fileName', 'fileUpload', 'description', 'adminName',
    ];
}
