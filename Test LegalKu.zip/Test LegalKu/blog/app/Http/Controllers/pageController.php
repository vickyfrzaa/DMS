<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\document;
use Illuminate\Support\Facades\DB;

class pageController extends Controller
{
    public function register(){
        return view ('auth.register');
    }

    public function index(){
        $addDocument = DB::table('documents')
        ->get();

        return view('index')
            ->with('documents', $addDocument);
    }

    public function create(){
        return view ('create');
    }

    public function createDetail(Request $request){
        $data = new document();

        $data->fileName = $request->input('fileName');
        $data->description = $request->input('description');
        $data->adminName = $request->input('adminName');

        if($request->hasfile('fileUpload')){
            $file = $request->file('fileUpload');
            $extension = $file->getClientOriginalExtension();
            $filename = time(). '.'. $extension;
            $file->move('img/',$filename);
            $data->fileUpload = $filename;
        }

        $data->save();

        return redirect('index');
    }

    public function edit(){
        $addDocument = DB::table('documents')
        ->get();

        return view('edit')
            ->with('documents', $addDocument);
    }

    public function editDetail(Request $request){
        $data = document::where('documentId', $request->documentId)->first();

        $data->fileName = $request->input('fileName');
        $data->description = $request->input('description');
        $data->adminName = $request->input('adminName');

        if($request->hasfile('fileUpload')){
            $file = $request->file('fileUpload');
            $extension = $file->getClientOriginalExtension();
            $filename = time(). '.'. $extension;
            $file->move('img/',$filename);
            $data->fileUpload = $filename;
        }

        $data->save();

        return redirect('index');
    }

    public function delete($documentId){
        DB::table('documents')->where('documentId',$documentId)->delete();
        return redirect('index');
    }

    public function date(){
        $addDocument = DB::table('documents')
        ->get();

        return view('date')
            ->with('documents', $addDocument);
    }

    public function dateSearch(Request $request){
        $search = $request->get('search');

        $searchDate = DB::table('documents')
        ->where('updated_at', 'like', '%'.$search.'%')
        ->orderBy('updated_at', 'ASC')
        ->get();

        $addDocument = DB::table('documents')
        ->get();

        if($search)
        {
            return view('date')
            ->with('documents', $searchDate);
        }
        else
        {
            return view('index')
            ->with('documents', $addDocument);
        }
    }

    public function search(Request $request){
        $search = $request->get('search');

        $searchfile = DB::table('documents')
        ->where('fileName', 'like', '%'.$search.'%')
        ->orwhere('adminName', 'like', '%'.$search.'%')
        ->orderBy('updated_at', 'ASC')
        ->get();

        $addDocument = DB::table('documents')
        ->get();

        if($search)
        {
            return view('date')
            ->with('documents', $searchfile);
        } else {
            return view('index')
            ->with('documents', $addDocument);
        }
    }

}
