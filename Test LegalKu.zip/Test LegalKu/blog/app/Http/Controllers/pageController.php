<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\document;
use Illuminate\Support\Facades\DB;

class pageController extends Controller
{
    public function register(){
        return view ('auth.register');
    }

    public function index(){
        $addDocument = DB::table('documents')
        ->get();

        return view('index')
            ->with('documents', $addDocument);
    }

    public function create(){
        return view ('create');
    }

    public function createDetail(Request $request){
        $data = new document();

        $data->fileName = $request->input('fileName');
        $data->description = $request->input('description');
        $data->adminName = $request->input('adminName');

        if($request->hasfile('fileUpload')){
            $file = $request->file('fileUpload');
            $extension = $file->getClientOriginalExtension();
            $filename = time(). '.'. $extension;
            $file->move('img/',$filename);
            $data->fileUpload = $filename;
        }

        $data->save();

        return redirect('index');
    }

    public function edit(Request $request){
        $data = document::where('documentId', $request->documentId)->first();

        $data->fileName = $request->input('fileName');
        $data->description = $request->input('description');
        $data->adminName = $request->input('adminName');

        if($request->hasfile('fileUpload')){
            $file = $request->file('fileUpload');
            $extension = $file->getClientOriginalExtension();
            $filename = time(). '.'. $extension;
            $file->move('img/',$filename);
            $data->fileUpload = $filename;
        }

        $data->save();

        return redirect('index');
    }

    public function delete($documentId){
        DB::table('documents')->where('documentId',$documentId)->delete();
        return redirect('index');
    }

}
