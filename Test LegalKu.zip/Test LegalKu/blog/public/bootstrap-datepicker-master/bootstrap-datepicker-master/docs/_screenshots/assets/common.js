document.write("<script src='../../node_modules/jquery/dist/jquery.slim.js'></script>");
document.write("<script src='../../js/bootstrap-datepicker.js'></script>");
