  <?php $__env->startSection('main-content'); ?>
    <!-- Dashboard -->
    <section class="content transition">
      <div class="container dashboard">
        <div class="row g-2 justify-content-center">
          <div class="col-md-6">
            <div class="text fw-bold fs-2">Dashboard</div>
          </div>
          <div class="col-md-4">
            <form class="d-flex" action="<?php echo e(asset('search')); ?>" method="GET">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search"/>
              <button class="btn btn-outline-danger" type="submit">
                <i class="fas fa-search"></i>
              </button>
            </form>
          </div>
        </div>

        <hr />
        <form class="row g-4" action="<?php echo e(asset('dateSearch')); ?>" method="GET">
          <div class="col-2">
            <label for="staticEmail2" class="form-label fw-bold fs-4">Date</label>
          </div>
          <div class="col-4">
            <div class="input-group data" id="datapicker">
              <input type="search" class="form-control datepick" placeholder="yyyy-mm-dd" name="search"/>
              <span class="input-group-append">
                <span class="input-group-text bg-white d-block datepick">
                  <i class="fas fa-calendar datepick"></i>
                </span>
              </span>
            </div>
          </div>
          <script type="text/javascript">
            $(function () {
              $(".datepick").datepicker({
                format: 'yyyy-mm-dd'
              });
            });
          </script>
          
          <div class="col-2">
            <button type="submit" class="btn btn-danger">
              <i class="fas fa-search"></i>
            </button>
          </div>
        </form>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">No.</th>
              <th scope="col">File Name</th>
              <th scope="col">File Upload</th>
              <th scope="col">Description</th>
              <th scope="col">Admin</th>
              <th scope="col">Time</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
          <?php $no = 1; ?>
          <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($no++); ?></th>
              <td><?php echo e($data->fileName); ?></td>
              <td><?php echo e($data->fileUpload); ?></td>
              <td><?php echo e($data->description); ?></td>
              <td><?php echo e($data->adminName); ?></td>
              <td><?php echo e($data->updated_at); ?></td>
              <td>
                <a href="<?php echo e(asset('edit')); ?> / <?php echo e($data->documentId); ?>" class="btn">
                  <i class="fas fa-pencil-alt pe-3"></i>
                </a>
                <a href="<?php echo e(asset('delete')); ?> / <?php echo e($data->documentId); ?>" class="btn" onclick="return confirm('Are you sure you want to delete this document ?')">
                  <i class="fas fa-trash-alt ps-3"></i>
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Vicky Fahreza\Test LegalKu\blog\resources\views/date.blade.php ENDPATH**/ ?>