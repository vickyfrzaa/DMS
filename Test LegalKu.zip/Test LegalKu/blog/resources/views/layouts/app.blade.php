<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- Datepicker -->
    <link rel="stylesheet" href="bootstrap-datepicker-master/bootstrap-datepicker-master/dist/css/bootstrap-datepicker.min.css" />

    <!-- CSS -->
    <link rel="stylesheet" href="css/index.css" />

    <!-- jquery -->
    <script src="js/jquery.min.js"></script>

    <title>LegalKu</title>
  </head>
  <body>
    <section class="topbar transition">
      <div class="bars">
        <button class="btn-transition" type="button" id="sidebar-toggle">
          <i class="fas fa-bars"></i>
        </button>
      </div>
      <div class="menu">
        <ul>
          <li>
            <div class="theme-switch-wrapper">
              <!-- <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                <button class="btn btn-outline-success" type="submit"><i class="fas fa-search"></i></button>
              </form> -->
            </div>
          </li>
          <li>
            <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt me-2"></i>Log Out 
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
          </li>
        </ul>
      </div>
    </section>

    <!-- Sidebar -->
    <section class="sidebar transition">
      <div class="logo">
        <a href="{{ url('index') }}" class="logo-sidebar">
          <img src="img/bur.jpg" alt="" height="60px" />
        </a>
      </div>
      <!-- Menu Sidebar -->
      <div class="sidebar-items">
        <ul>
          <li>
            <a href="{{ url('index') }}" class="transition active">
              <i class="fas fa-home"></i>
              <span>Dashboard</span>
            </a>
          </li>

          <li>
            <a href="{{ url('create') }}" class="transtition">
              <i class="fas fa-folder-plus"></i>
              <span> Add Document</span>
            </a>
          </li>
          <!-- <li>
            <a href="#" class="transtition">
              <i class="fas fa-folder-plus"></i>
              <span>Document</span>
            </a>
          </li> -->
        </ul>
      </div>
    </section>

    <!-- overlay -->
    <div class="sidebar-overlay"></div>

    @yield('main-content')

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- jquery -->
    <!-- <script src="js/jquery.min.js"></script> -->

    <!-- JS -->
    <script src="js/index.js"></script>

    <!-- Datepicker -->
    <script src="bootstrap-5/js/bootstrap.min.js"></script>
    <script src="bootstrap-datepicker-master/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>

    <!-- FONTAWESOME -->
    <script src="https://kit.fontawesome.com/7f2ed2a5ac.js" crossorigin="anonymous"></script>
  </body>
</html>
