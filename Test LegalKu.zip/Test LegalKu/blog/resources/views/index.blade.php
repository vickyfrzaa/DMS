@extends('layouts.app')
  @section('main-content')
    <!-- Dashboard -->
    <section class="content transition">
      <div class="container dashboard">
        <div class="row g-2 justify-content-center">
          <div class="col-md-6">
            <div class="text fw-bold fs-2">Dashboard</div>
          </div>
          <div class="col-md-4">
            <form class="d-flex" action="{{ asset('search') }}" method="GET">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search"/>
              <button class="btn btn-outline-danger" type="submit">
                <i class="fas fa-search"></i>
              </button>
            </form>
          </div>
        </div>

        <hr />
        <form class="row g-4" action="{{ asset('dateSearch') }}" method="GET">
          <div class="col-2">
            <label for="staticEmail2" class="form-label fw-bold fs-4">Date</label>
          </div>
          <div class="col-4">
            <div class="input-group data" id="datapicker">
            <input type="search" class="form-control datepick" placeholder="yyyy-mm-dd" name="search"/>
              <span class="input-group-append">
                <span class="input-group-text bg-white d-block datepick">
                  <i class="fas fa-calendar"></i>
                </span>
              </span>
            </div>
          </div>
          <script type="text/javascript">
            $(function () {
              $(".datepick").datepicker({
                format: 'yyyy-mm-dd'
              });
            });
          </script>
          
          <div class="col-2">
            <button type="submit" class="btn btn-danger">
              <i class="fas fa-search"></i>
            </button>
          </div>
         
        </form>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">No.</th>
              <th scope="col">File Name</th>
              <th scope="col">File Upload</th>
              <th scope="col">Description</th>
              <th scope="col">Admin</th>
              <th scope="col">Time</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
          @php $no = 1; @endphp
          @foreach ($documents as $data)
            <tr>
              <th scope="row">{{ $no++ }}</th>
              <td>{{ $data->fileName }}</td>
              <td>{{ $data->fileUpload }}</td>
              <td>{{ $data->description }}</td>
              <td>{{ $data->adminName }}</td>
              <td>{{ $data->updated_at }}</td>
              <td>
                <a href="{{ asset('edit') }} / {{ $data->documentId }}" class="btn">
                  <i class="fas fa-pencil-alt pe-3"></i>
                </a>
                <a href="{{ asset('delete') }} / {{ $data->documentId }}" class="btn" onclick="return confirm('Are you sure you want to delete this document ?')">
                  <i class="fas fa-trash-alt ps-3"></i>
                </a>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </section>
  @endsection