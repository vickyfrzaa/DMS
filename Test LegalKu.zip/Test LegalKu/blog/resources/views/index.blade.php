@extends('layouts.app')
  @section('main-content')
    <!-- Dashboard -->
    <section class="content transition">
      <div class="container dashboard">
        <div class="row g-2 justify-content-center">
          <div class="col-md-6">
            <div class="text fw-bold fs-2">Dashboard</div>
          </div>
          <div class="col-md-4">
            <form class="d-flex">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
              <button class="btn btn-outline-danger" type="submit">
                <i class="fas fa-search"></i>
              </button>
            </form>
          </div>
        </div>

        <hr />
        <form class="row g-4">
          <div class="col-2">
            <label for="staticEmail2" class="form-label fw-bold fs-4">Date</label>
            <input type="text" readonly class="form-control-plaintext" id="staticEmail2" />
          </div>
          <div class="col-4">
            <div class="input-group data" id="datapicker">
              <input type="text" class="form-control datepick" placeholder="dd/mm/yyyy" />
              <span class="input-group-append">
                <span class="input-group-text bg-white d-block datepick">
                  <i class="fas fa-calendar"></i>
                </span>
              </span>
            </div>
          </div>
          <script type="text/javascript">
            $(function () {
              $(".datepick").datepicker();
            });
          </script>
          
          <div class="col-2">
            <button type="submit" class="btn btn-danger">
              <i class="fas fa-search"></i>
            </button>
          </div>
         
        </form>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">No.</th>
              <th scope="col">File Name</th>
              <th scope="col">File Upload</th>
              <th scope="col">Description</th>
              <th scope="col">Admin Name</th>
              <th scope="col">Time</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
          @php $no = 1; @endphp
          @foreach ($documents as $data)
            <tr>
              <th scope="row">{{ $no++ }}</th>
              <td>{{ $data->fileName }}</td>
              <td>{{ $data->fileUpload }}</td>
              <td>{{ $data->description }}</td>
              <td>{{ $data->adminName }}</td>
              <td>{{ $data->updated_at }}</td>
              <td>
                <!-- Button trigger modal -->
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                  <i class="fas fa-pencil-alt pe-3"></i>
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body" style="backgroun-color:">
                        <form>
                          @csrf
                        <div class="mb-3">
                          <label for="exampleFormControlInput1" class="form-label">File Name</label>
                          <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="File Name" name="fileName" />
                        </div>
                        <div class="mb-3">
                          <label for="exampleFormControlInput1" class="form-label">File Upload</label>
                          <input type="file" class="form-control" id="inputGroupFile01" name="fileUpload" />
                        </div>
                        <div class="mb-3">
                          <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="description"></textarea>
                        </div>
                        <div class="mb-3">
                          <label for="exampleFormControlInput1" class="form-label">Admin</label>
                          <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="{{ Auth::user()->name }}" name="adminName" value="{{ Auth::user()->name }}" aria-label="readonly input" readonly/>
                        </div>
                        </form>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Save Change</button>
                      </div>
                    </div>
                  </div>
                </div>
                <a href="{{ asset('delete') }} / {{ $data->documentId }}"  class="btn"><i class="fas fa-trash-alt ps-3"></i></a>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </section>
  @endsection