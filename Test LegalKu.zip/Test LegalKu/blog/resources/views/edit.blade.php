@extends('layouts.app')
  @section('main-content')
    <!-- Add -->
    <section class="content transition">
      <div class="container dashboard">
        <div class="row">
          <div class="col-md-6">
            <div class="text fw-bold fs-2" style="padding-left: 50px">Add Document</div>
          </div>
        </div>
        <hr />

        <div class="container my-5">
          <div class="row justify-content-center">
            <div class="col-8">
              <div class="card rounded shadow">
                <div class="card-header d-flex justify-content-between fw-bold">
                  <div class="p-2 fw-bold h2">Edit Document</div>
                </div>
                <div class="card-body" style="background-color: #f0f8ff">
                  <form method="POST" enctype = "multipart/form-data" action="{{ route('editDetail') }}">
                    @foreach ('$document as $data')
                    @csrf
                    <div class="mb-3">
                      <label for="exampleFormControlInput1" class="form-label">File Name</label>
                      <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="File Name" name="fileName" value="{{ old('fileName')?? $data->FileName }}" />
                    </div>
                    <div class="mb-3">
                      <label for="exampleFormControlInput1" class="form-label">File Upload</label>
                      <input type="file" class="form-control" id="inputGroupFile01" name="fileUpload" value="{{ old('fileUpload')?? $data->FileUpload }}"/>
                    </div>
                    <div class="mb-3">
                      <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="description">{{ old('description')?? $data->description }}</textarea>
                    </div>
                    <div class="mb-3">
                      <label for="exampleFormControlInput1" class="form-label">Admin</label>
                      <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="{{ Auth::user()->name }}" name="adminName" value="{{ old('adminName')?? $data->adminName }}" aria-label="readonly input" readonly/>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                      <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                    @endforeach
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  @endsection